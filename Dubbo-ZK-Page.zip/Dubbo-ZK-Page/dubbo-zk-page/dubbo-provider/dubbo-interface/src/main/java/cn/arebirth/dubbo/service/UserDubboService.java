package cn.arebirth.dubbo.service;

public interface UserDubboService {
    Integer login(String username, String password);
}
