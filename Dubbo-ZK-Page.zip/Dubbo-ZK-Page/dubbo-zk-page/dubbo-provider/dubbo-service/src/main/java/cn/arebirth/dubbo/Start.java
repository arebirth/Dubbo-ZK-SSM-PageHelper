package cn.arebirth.dubbo;

import com.alibaba.dubbo.container.Main;

public class Start {
    public static void main(String[] args) {
        Main.main(args);
    }
}
