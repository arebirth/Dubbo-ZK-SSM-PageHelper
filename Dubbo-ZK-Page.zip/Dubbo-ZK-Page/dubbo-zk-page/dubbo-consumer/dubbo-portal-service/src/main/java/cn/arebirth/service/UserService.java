package cn.arebirth.service;

public interface UserService {
    Integer login(String username, String password);
}
